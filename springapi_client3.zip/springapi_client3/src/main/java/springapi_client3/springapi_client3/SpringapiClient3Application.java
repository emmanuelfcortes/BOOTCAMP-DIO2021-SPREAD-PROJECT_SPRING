package springapi_client3.springapi_client3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringapiClient3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringapiClient3Application.class, args);
	}

}
