package springapi_client3.springapi_client3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringapiClient3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
